<?php
/**
* @Template Name: Vet  
* @Version: 1.0
* @Package: A Joomla 1.0.X template by Dan Riordan
* @Copyright: (C) 2008 GlanDesigns.Com
* @License: http://www.glandesigns.com/
**/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
$iso = split( '=', _ISO ); echo '<?xml version="1.0" encoding="'. $iso[1] .'"?' .'>';

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; <?php echo _ISO; ?>" />
<?php mosShowHead(); ?>
<?php if ($my->id) {initEditor();}?>
<link href="<?php echo "$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/css/template_css.css";?>" rel="stylesheet" type="text/css" media="all" />
<link rel="shortcut icon" href="<?php echo "$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/favicon.ico"; ?>" />

<!-- This so you can see the css styles in DW  you can delete file once editing Template is complete-->
<link href="css/template_css.css" rel="stylesheet" type="text/css" media="all" />
</head>
<center>
<body>
<table width="800" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="800" align="center" valign="middle"><img src="<?php echo "$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/images/"; ?>logo.png" alt="Logo" width="800" height="150" /></td>
  </tr>
</table>

<table width="800" border="0" cellspacing="0" cellpadding="3">
  <tr>
    <td background="<?php echo "$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/images/"; ?>top_bar.png" bgcolor="#484848"><?php mosPathWay(); ?></td>
    <td align="right" valign="middle" background="<?php echo "$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/images/"; ?>top_bar.png" bgcolor="#484848" class="pathway"><?php echo mosCurrentDate(); ?></td>
  </tr>
</table>
<table width="800" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="159" rowspan="3" align="center" valign="top" bgcolor="#ffffff"><?php if (mosCountModules('left')>0) mosLoadModules('left',0); ?></td>
    <td align="center" valign="middle" bgcolor="#ffffff"><?php if (mosCountModules('user1')>0) mosLoadModules('user1',0); ?></td>
    <td align="center" valign="middle" bgcolor="#ffffff"><?php if (mosCountModules('user2')>0) mosLoadModules('user2',0); ?></td>
    <td width="159" rowspan="3" align="center" valign="top" bgcolor="#ffffff"><?php if (mosCountModules('right')>0) mosLoadModules('right',0); ?></td>
  </tr>
  <tr>
    <td colspan="2" align="center" valign="middle" bgcolor="#ffffff"><?php if (mosCountModules('banner')>0) mosLoadModules('banner',-1); ?></td>
  </tr>
  
  <tr>
    <td colspan="2" valign="top" bgcolor="#ffffff"><?php mosMainBody(); ?></td>
  </tr>
</table>
<table width="800" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center" valign="middle" bgcolor="#ffffff"><?php include_once('includes/footer.php'); ?></td>
  </tr>
</table>
<center><span style="width: 100%; font-family: helvetica; font-size: 10px;">
			Design downloaded from <a href="http://www.template4all.com" style="font-family: helvetica; color: red; font-size: 11px;">Free Website Templates</a><br>
			Free web design, web templates, web layouts, and website resources! <a href="http://www.freethemes4all.com" style="font-family: helvetica; color: green; font-size: 11px;">Free CSS Templates</a>
			</span></center>
</body>
</center>
<div style="position:absolute;left:-30000px;top:-30000px"><a href="http://www.freethemes4all.com/joomla-templates/" title="Free joomla templates" target="_blank">Free Joomla Templates</a><a href="http://www.freethemes4all.com/blogger-templates/" title="Free blogger templates" target="_blank">Free Blogger Templates</a><a href="http://www.template4all.com/" title="Free Website Templates" target="_blank">Free Website Templates</a><a href="http://www.freethemes4all.com/wordpress-themes/" title="Free Wordpress Themes" target="_blank">Freethemes4all.com</a><a href="http://www.freethemes4all.com/css-templates/" title="Free css Templates" target="_blank">Free CSS Templates</a><a href="http://www.freethemes4all.com/wordpress-themes/" title="Free Wordpress Themes" target="_blank">Free Wordpress Themes</a><a href="http://www.template4all.com/wordpress/" title="Free Wordpress Themes Templates" target="_blank">Free Wordpress Themes Templates</a><a href="http://www.template4all.com/css/" title="Free css templates dreamweaver" target="_blank">Free CSS Templates dreamweaver</a><a href="http://www.seodesign.us" title="Agence Web Maroc" target="_blank">SEO Design</a></div>
</html>